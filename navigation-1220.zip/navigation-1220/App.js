import React from 'react';
import { StyleSheet,Button, Text, View } from 'react-native';
import {
    DrawerNavigator, TabNavigator, StackNavigator,
} from 'react-navigation';




const friend = ['lisi','zhangsan','wangwu'];
const MsgList = ( {navigation} ) => (
    <View>
        {
            // friend.map(name => {
            //     return <Text key={name}> 联系人:{name}
            //         <Text key={name}> 联系人:{name} </Text >
            //     </Text >
            //
            // })
            friend.map(name => (
                <View key={name}>
                    <Button
                        title={`跟${name}的聊天`}
                        onPress={ () => navigation.navigate('ChatRoom', {name})}
                    />
                </View>
            ))
        }
    </View>
)

const Contact = () => (
    <View>
        {
            friend.map(name => (
                <Text key={name}> 联系人:{name} </Text >
            ))
        }
    </View>
);

const  Message = () => {
    return <View>
        {
            friend.map(name => (
                <Text key={name}> {name}发送了消息 </Text>
            ))
        }
    </View>
};


// class ChatRoom extends React.Component {
//     //为了将 NavigationOptions 跟组件本身放到一起,也可以写到TabNavigator里边
//     static  navigationOptions = ({ navigation }) => ({
//         title: `Chat with ${navigation.state.params.name}`
//     });
//     render() {
//         const { navigation } = this.props;
//         const name = navigation.state.params.name;
//         return <View>
//                 <Text>this is chatroom woth {name}</Text>
//             </View>
//     }
// }


class ChatRoom extends React.Component {
    static navigationOptions = ( {navigation}) => (

        {title: `chat with ${navigation.state.params.name}`}
    );

    render() {
        const { navigation } = this.props;
        const name = navigation.state.params.name;
        return <View>
            <Text>this chatroom with {name}</Text>
        </View>
    }

}

// ChatRoom = ( {navigation}  ) => {

//   const name = navigation.state.params.name;
//   return <View>
//           <Text>this is chatroom woth {name}</Text>
//       </View>
// }


//TabBar
const RootTabNavigator = TabNavigator({
    MsgList: {
        screen: MsgList,
        navigationOptions: {
            title: '消息'
        }
    },
    Constant: {
        screen: Contact,
        navigationOptions:{
            title:'联系人'
        }
    },

    Message: {
        screen: Message,
        navigationOptions: {
            title: '消息'
        }
    }


})

//导航条
const RootNavigator = StackNavigator({
    Rootab: {
        screen: RootTabNavigator,
        navigationOptions: ({navigation}) => ({
            headerLeft: <Button title='头像' onPress={() => navigation.navigate('DrawerOpen')}/> //DrawerOpen固定写法
        })
    },
    ChatRoom: {
        screen: ChatRoom,
        // navigationOptions: ( {navigation}) => ({
        //   title: `Chat with ${navigation.state.params.name}`
        // })
    }
})

const settingView1 = ( {navigation} ) => (
    <View style= {style.settingViewStyle} >
        <Text  > setting view A</Text>
        <Button
            title='返回上一页面'
            onPress={ () => navigation.goBack() }
        >
        </Button>
    </View>
)

const settingView2 = ( {navigation} ) => {
    return <View style={style.settingViewStyle}>
        <Text>setting view B</Text>
        <Button
            title='返回上一页'
            onPress={ ()=> navigation.goBack() }
        ></Button>
    </View>

}


//策侧效果
const myApp = DrawerNavigator({
    //默认第一个是全屏的
    RightScreen: {
        screen: RootNavigator,
        navigationOptions: {
            title:'首页'
        }
    },
    //以下是设置界面的
    SettingA: {
        screen: settingView1,
        navigationOptions: {
            title: '上传文件'
        }
    },

    SettingB: {
        screen: settingView2,
        navigationOptions: {
            title:'空间'
        }
    },
},{
    drawerPosition: 'left', // 默认就是left， 如果你想隐藏做右侧修改为right即可
    contentComponent: props => <CustomDrawerContentComponent {...props} />,
});



const CustomDrawerContentComponent = (props) => {
    return <View style={{ elevation: 10 }}>
        <View style={{ height: 200, backgroundColor: '#6ABFA0' }}>
            <View style={{ marginTop: 50, alignItems: 'center' }}>
                <Button title="设置页面1"
                        onPress={() => props.navigation.navigate("Setting1")}
                />
                <Button title="设置页面2"
                        onPress={() => props.navigation.navigate("Setting2")}
                />
                <Text> Footer: Designed by Magicly </Text>
            </View>
        </View>
    </View>
};




const style = StyleSheet.create({
    settingViewStyle: {
        top:22+20,
        flex:0.1,
        flexDirection:'column',
        justifyContent:'center',
        backgroundColor:'cyan'
    },
})



export default myApp;